DB_HOST = "127.0.0.1"
DB_USER = "homestead"
DB_PASSWORD = "secret"
DB_NAME = "homestead"

def DatabaseConfig():
    global DB_HOST, DB_USER, DB_PASSWORD, DB_NAME
