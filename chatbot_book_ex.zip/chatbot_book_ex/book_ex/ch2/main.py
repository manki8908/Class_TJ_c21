# main.py
import calc # calc 모듈을 불러옴. main.py와 같은 경로에 있어야 함

a = calc.add(10, 20) # calc 모듈의 add 함수
print("add = {}".format(a))

b = calc.mul(10, 2) # calc 모듈의 mul 함수
print("add = {}".format(b))