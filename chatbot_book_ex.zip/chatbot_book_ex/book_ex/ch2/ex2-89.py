import numpy as np

arr = np.array([1, 2, 3])
print(arr)
print(type(arr))