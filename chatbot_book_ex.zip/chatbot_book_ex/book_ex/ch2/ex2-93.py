import numpy as np

A = np.array([ [1, 2], [3, 4] ]) # 2x2 행렬
k = 10 # 스칼라
C = k * A # 스칼라곱
print(C) # 결과는 2x2 행렬