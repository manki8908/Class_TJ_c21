# calc.py - calc 모듈 파일

# 덧셈 함수
def add(a, b): return a + b
# 뺄셈 함수
def sub(a, b): return a - b
# 곱셈 함수
def mul(a, b): return a * b
# 나눗셈 함수
def div(a, b): return a / b