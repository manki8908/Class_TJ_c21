import numpy as np

A = np.array([ [1, 2], [3, 4] ])
B = np.array([ [1, 1], [1, 1] ])
C = A + B # 행렬 덧셈 연산
print(C)