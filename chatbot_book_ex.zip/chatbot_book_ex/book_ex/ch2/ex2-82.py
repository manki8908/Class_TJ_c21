try:
    a = 10
    b = 0
    c = a / b  # 0으로 나눌 수 없다.
    print(c)
except Exception as e:
    print(e)
