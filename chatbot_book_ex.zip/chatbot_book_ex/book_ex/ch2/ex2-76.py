class Chatbot:

    def sayHello(self):
        print("say hello")

    def sayMyName(self):
        print("My name is Kbot :D")


# 챗봇 인스턴스 생성
chatbot = Chatbot()
chatbot.sayHello()
chatbot.sayMyName()
